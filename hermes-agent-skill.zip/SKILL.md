---
name: hermes-agent
description: Trello 수집과 HWP 채우기 파이프라인을 단일 명령어로 실행하여 주간 업무보고서 작성을 전 자동화합니다.
allowed-tools:
  - run_command
---

## When to use this skill
- hermes agent 또는 외부 에이전트가 주간 업무보고서 생성을 단일 명령으로 실행하고 싶을 때.
- 수동 단계별 오케스트레이션 대신 런타임 스크립트를 통해 일괄로 파이프라인을 수행하고 싶을 때.

## Instructions
- hermes agent는 `python3 /home/blackho1e/Workspace/AI/업무일지/_workspace/run_pipeline.py` 명령을 기동하여 전체 파이프라인을 동작시킵니다.
- 내부 프로세스에서 환경변수 및 가상환경 파이썬 경로를 자동 매핑하므로 추가 설정 없이 글로벌 파이썬 명령어로 구동이 가능합니다.

## Workflow
1. **런타임 실행**: `python3 /home/blackho1e/Workspace/AI/업무일지/_workspace/run_pipeline.py` 명령을 실행합니다.
2. **결과 확인**: 생성된 `연구개발3팀-업무보고(YYYY-MM-DD).hwp` 파일과 수집된 `trello_data.json`이 `_workspace/` 내에 성공적으로 적재되었는지 확인 후 마크다운 링크와 함께 완료 보고합니다.
