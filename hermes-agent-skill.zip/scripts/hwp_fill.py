import hwpkit
import json
import shutil
import os
import re

TEMPLATE_PATH = "/home/blackho1e/Workspace/AI/업무일지/_workspace/rt.hwp"
DATA_PATH = "/home/blackho1e/Workspace/AI/업무일지/_workspace/trello_data.json"

def clean_item_name(item, category_name):
    keywords = [category_name]
    if category_name == "신규 마이닝 (입력2)":
        keywords.extend(["신규 마이닝", "입력2", "신규마이닝"])
    elif category_name == "분석관리자":
        keywords.extend(["분석관리자"])
    elif category_name == "로봇":
        keywords.extend(["로봇"])
    elif category_name == "a2":
        keywords.extend(["a2"])
    elif category_name == "분석서비스":
        keywords.extend(["분석서비스"])
    elif category_name == "적격관리자":
        keywords.extend(["적격관리자"])
        
    for kw in keywords:
        escaped_kw = re.escape(kw)
        pattern = re.compile(rf"^{escaped_kw}\s*[-:]\s*", re.IGNORECASE)
        if pattern.match(item):
            return pattern.sub("", item)
        pattern_simple = re.compile(rf"^{escaped_kw}\s+", re.IGNORECASE)
        if pattern_simple.match(item):
            return pattern_simple.sub("", item)
    return item

def fill_category(records, category_name, items, para_range):
    first_idx = para_range[0]
    
    cleaned_items = [clean_item_name(item, category_name) for item in items]
    
    if not cleaned_items:
        # No items: do not write the header, fill all paragraphs in range with " "
        for idx in para_range:
            hwpkit.replace_text(records, idx, " ")
    else:
        # Has items: first item goes into first paragraph with header
        hwpkit.replace_text(records, first_idx, f"# {category_name}\n- {cleaned_items[0]}")
        
        rem_paras = list(para_range[1:])
        rem_items = list(cleaned_items[1:])
        
        while rem_items:
            if len(rem_paras) == 1:
                # If only one paragraph left, put all remaining items in it with soft breaks
                last_idx = rem_paras[0]
                text_lines = [f"- {item}" for item in rem_items]
                hwpkit.replace_text(records, last_idx, "\n".join(text_lines))
                rem_paras.pop(0)
                rem_items.clear()
            elif len(rem_paras) > 1:
                idx = rem_paras.pop(0)
                item = rem_items.pop(0)
                hwpkit.replace_text(records, idx, f"- {item}")
            else:
                # If no paragraphs left, append all items to the first paragraph using soft breaks
                current_text = f"# {category_name}\n" + "\n".join([f"- {item}" for item in cleaned_items])
                hwpkit.replace_text(records, first_idx, current_text)
                rem_items.clear()
                
        # Fill any unused paragraphs in the range with " "
        for idx in rem_paras:
            hwpkit.replace_text(records, idx, " ")

def main():
    print(f"Loading data from {DATA_PATH}...")
    with open(DATA_PATH, "r", encoding="utf-8") as f:
        data = json.load(f)
        
    # Generate OUTPUT_PATH dynamically from the period (e.g. "2026. 06. 22 ~ 06. 26" -> "2026-06-26")
    period = data["period"]
    parts = period.split("~")
    year = parts[0].strip().split(".")[0].strip()
    end_date_part = parts[1].strip()
    end_month, end_day = [x.strip() for x in end_date_part.split(".")]
    date_str = f"{year}-{end_month}-{end_day}"
    
    output_filename = f"연구개발3팀-업무보고({date_str}).hwp"
    OUTPUT_PATH = os.path.join("/home/blackho1e/Workspace/AI/업무일지/_workspace", output_filename)
        
    print(f"Copying template from {TEMPLATE_PATH} to {OUTPUT_PATH}...")
    shutil.copy(TEMPLATE_PATH, OUTPUT_PATH)
    
    # We define the edit function to pass to fill_hwp
    def edit_fn(records):
        print("Applying changes to HWP paragraphs...")
        
        # 1. Period (P 2)
        period_text = f"기간 : {data['period']}                                  보고자 : 강민주"
        hwpkit.replace_text(records, 2, period_text)
        
        # 2. 금주 예정 (P 8) - Always fixed to "분석관리자, a2, 로봇 - 유지보수작업"
        hwpkit.replace_text(records, 8, "분석관리자, a2, 로봇 - 유지보수작업")
        
        # 3. 금주 실시 (P 12 ~ P 25)
        this_week = data["this_week"]
        fill_category(records, "분석서비스", this_week.get("분석서비스", []), [12, 13, 14])
        fill_category(records, "분석관리자", this_week.get("분석관리자", []), [16, 17, 18])
        fill_category(records, "로봇", this_week.get("로봇", []), [19, 20])
        fill_category(records, "a2", this_week.get("a2", []), [22])
        fill_category(records, "적격관리자", this_week.get("적격관리자", []), [24])
        fill_category(records, "신규 마이닝 (입력2)", this_week.get("신규 마이닝 (입력2)", []), [25])
        
        # 4. 작성자 성명 (P 26 ~ P 27)
        writers = data.get("writers", [])
        w1 = f"\n{writers[0]}\n{writers[1]}" if len(writers) > 1 else f"\n{writers[0]}" if len(writers) > 0 else " "
        w2 = writers[2] if len(writers) > 2 else " "
        hwpkit.replace_text(records, 26, w1)
        hwpkit.replace_text(records, 27, w2)
        
        # 5. 차주 예정 (P 30) - Set to "분석관리자, a2, 로봇 - 유지보수작업"
        hwpkit.replace_text(records, 30, "분석관리자, a2, 로봇 - 유지보수작업")
        
    print("Executing fill_hwp...")
    sizes = hwpkit.fill_hwp(TEMPLATE_PATH, OUTPUT_PATH, edit_fn)
    print(f"HWP fill complete. Sizes: {sizes}")
    
    # Patch OLE header: Set Directory Sector Count (offset 40) to 0 for V3 compliance.
    # This prevents Windows Hancom Office from rejecting the file as corrupted.
    print("Patching OLE header for Windows Hancom Office compatibility...")
    with open(OUTPUT_PATH, "r+b") as f:
        f.seek(40)
        f.write(b"\x00\x00\x00\x00")
        
    print(f"Result saved to {OUTPUT_PATH}")

if __name__ == "__main__":
    main()
