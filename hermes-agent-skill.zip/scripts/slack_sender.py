import os
import sys
import urllib.request
import urllib.parse
import json

def main():
    if len(sys.argv) < 2:
        print("Usage: python slack_sender.py <file_path>")
        sys.exit(1)
        
    file_path = sys.argv[1]
    if not os.path.exists(file_path):
        print(f"File not found: {file_path}")
        sys.exit(1)
        
    token = os.environ.get("SLACK_BOT_TOKEN", "xoxb-7126158144-8612999879521-HjNG0HnCOGWRwvan7aZIZW2W")
    channel_id = os.environ.get("SLACK_CHANNEL_ID", "C0BGT9F3GBE")
    
    if not token or not channel_id:
        print("Warning: SLACK_BOT_TOKEN or SLACK_CHANNEL_ID environment variables are missing. Skipping Slack upload.")
        sys.exit(0)
        
    filename = os.path.basename(file_path)
    file_size = os.path.getsize(file_path)
    
    try:
        # Step 1: getUploadURLExternal
        print("Requesting upload URL from Slack API...")
        url = "https://slack.com/api/files.getUploadURLExternal"
        params = {
            "filename": filename,
            "length": file_size
        }
        data = urllib.parse.urlencode(params).encode('utf-8')
        req = urllib.request.Request(url, data=data, method='POST')
        req.add_header('Authorization', f'Bearer {token}')
        req.add_header('Content-Type', 'application/x-www-form-urlencoded')
        
        with urllib.request.urlopen(req) as res:
            res_data = json.loads(res.read().decode('utf-8'))
            if not res_data.get("ok"):
                print(f"Failed to get upload URL: {res_data.get('error')}")
                sys.exit(1)
            upload_url = res_data["upload_url"]
            file_id = res_data["file_id"]
            
        # Step 2: Upload file binary data to upload_url
        print(f"Uploading file binary to {upload_url[:60]}...")
        with open(file_path, 'rb') as f:
            file_data = f.read()
            
        req2 = urllib.request.Request(upload_url, data=file_data, method='POST')
        req2.add_header('Content-Type', 'application/octet-stream')
        
        with urllib.request.urlopen(req2) as res2:
            if res2.status != 200:
                print(f"Binary upload failed with status: {res2.status}")
                sys.exit(1)
                
        # Step 3: completeUploadExternal
        print("Completing upload on Slack channel...")
        url3 = "https://slack.com/api/files.completeUploadExternal"
        files_param = [{"id": file_id, "title": filename}]
        params3 = {
            "files": json.dumps(files_param),
            "channel_id": channel_id,
            "initial_comment": f"이번 주 주간 업무보고서 HWP 파일을 전송합니다. (파일명: {filename})"
        }
        data3 = urllib.parse.urlencode(params3).encode('utf-8')
        req3 = urllib.request.Request(url3, data=data3, method='POST')
        req3.add_header('Authorization', f'Bearer {token}')
        req3.add_header('Content-Type', 'application/x-www-form-urlencoded')
        
        with urllib.request.urlopen(req3) as res3:
            res3_data = json.loads(res3.read().decode('utf-8'))
            if res3_data.get("ok"):
                print("Successfully uploaded file to Slack.")
            else:
                print(f"Failed to complete upload: {res3_data.get('error')}")
                sys.exit(1)
                
    except Exception as e:
        print(f"Slack upload error: {e}")
        sys.exit(1)

if __name__ == "__main__":
    main()
