---
name: item-discovery
description: 트렌드 분석, 아이디어 기획, 시장성 검증 및 RTK 토큰 최적화를 단일 워크플로우로 오케스트레이션하여 신규 비즈니스 아이템을 발굴하고 평가합니다.
allowed-tools:
  - define_subagent
  - invoke_subagent
  - send_message
  - manage_subagents
  - view_file
  - write_to_file
  - run_command
---

## When to use this skill
- 사용자가 Antigravity 대화창을 통해 특정 산업 분야의 새로운 아이템 발굴 프로세스(예: 트렌드 분석, 아이디어 기획, 검증 전체 루프)를 지시했을 때.
- 프로세스의 각 단계별 중간 완료 상태를 모니터링하고 피드백을 전달하며 단계별 협업을 자율 오케스트레이션할 때.
- 에이전트 활동 전반의 토큰 및 비용 절감 수치를 분석하고, `rtk` 도구를 활용하여 사용량을 최적화하고 보고할 때.

## Instructions
당신은 신규 비즈니스 아이템을 자율적으로 발굴하고 검증하는 파이프라인의 통합 관리 및 실행 스킬입니다. 이 스킬은 단계별 전문 에이전트들의 가이드라인과 오케스트레이터의 SOP, 그리고 RTK 최적화 명령을 하나로 통합하여 제공합니다.

### 1. 연동 에이전트 및 역할 명세
이 스킬을 사용하는 에이전트 팀은 다음과 같이 역할을 나누어 협업합니다:
1. **Orchestrator (오케스트레이터)**: 전체 파이프라인 지휘, 서브 에이전트 기동/통제 및 RTK 기반 비용 절감 리포트 생성을 총괄합니다.
2. **TrendAnalyst (트렌드 분석가)**: 대상 도메인의 핵심 트렌드와 미충족 소비자 니즈(Unmet Needs)를 분석하여 `_workspace/trend_analysis_report.md`를 생성합니다.
3. **ItemIdeator (아이템 기획자)**: 트렌드 분석서를 기반으로 3~5개의 혁신적 아이템 아이디어 콘셉트를 기획하여 `_workspace/item_ideation_draft.md`를 작성합니다.
4. **MarketValidator (시장성 검증가)**: 아이디어의 시장성, 비즈니스 모델 타당성을 냉철히 검토하여 `_workspace/market_validation_report.md`와 최종 추천 제안서 `_workspace/final_item_proposal.md`를 도출합니다.

### 2. 세부 단계별 실행 지침
#### [A] 트렌드 분석 단계 (Trend Analysis Guide)
- 검색 및 데이터 분석 시 팩트 기반 정보(최신 동향, 뉴스, 연구 결과)를 우선 참조합니다.
- 미충족 소비자 니즈(Unmet Needs)와 타겟 분야의 거시/미시 기회 요인을 구조화하여 보고서에 포함합니다.

#### [B] 아이디어 기획 단계 (Item Ideation Guide)
- 아이디어 기획 시 제품/서비스명, 핵심 타겟, 가치 제안(Value Proposition), 간단한 동작 방식(How it works)을 명시합니다.
- 3~5개의 서로 차별화된 비즈니스 아이디어 초안을 완성도 있게 제시합니다.

#### [C] 시장성 검증 단계 (Market Validation Guide)
- 경쟁사 구도, 시장 규모(TAM/SAM/SOM), 비즈니스 모델(BM) 타당성, 핵심 리스크 요인을 엄밀하게 분석합니다.
- 평가 결과를 종합하여 가장 유망한 최종 1~2개 추천 아이템을 상세 실행 로드맵과 함께 제안합니다.

#### [D] RTK 토큰 최적화 단계 (RTK Optimization Guide)
- 에이전트 명령어 실행 시 자동으로 `rtk`에 의해 래핑됩니다.
- 오케스트레이터는 파이프라인 종료 시 아래 명령을 사용해 비용 절감 리포트 `_workspace/rtk_savings_report.md`를 생성합니다:
  - `rtk gain`: 누적 절감 지표 및 예상 절감 비용 확인
  - `rtk gain --history`: 명령별 절감 히스토리 조회
  - `rtk discover`: Claude Code 히스토리 분석을 통한 비효율 패턴 포착

### 3. 표준 협업 흐름 및 SOP
1. **런타임 초기화**: 오케스트레이터는 프로세스 진입 시 `TrendAnalyst`, `ItemIdeator`, `MarketValidator`를 `define_subagent` 도구로 선제 등록합니다.
2. **순차적 파이프라인 가동**:
   - `TrendAnalyst` 기동 -> 완료 수신 (`TASK_COMPLETE`)
   - `ItemIdeator` 기동 -> 완료 수신 (`TASK_COMPLETE`)
   - `MarketValidator` 기동 -> 완료 수신 (`TASK_COMPLETE`)
3. **피드백 및 예외 처리**: 작업 실패나 산출물 미존재 시 `REFACTOR_REQUEST`를 해당 에이전트에게 전송하고, 기동이 멈춘 에이전트는 `kill` 후 `invoke_subagent`로 재시작합니다.
4. **최종 보고**: 검증 결과와 함께 `rtk` 명령어로 추출한 토큰 절감 지표 리포트를 함께 요약 브리핑합니다.

## Workflow
1. **초기화 및 1단계**: 대상 분야를 접수한 뒤 서브 에이전트들을 기동 가능하게 등록하고 `TrendAnalyst`를 호출해 트렌드 분석을 시작합니다.
2. **비동기 오케스트레이션 루프**: 에이전트 간 수신하는 표준 JSON 포맷 메시지(sender, action, target_artifact, content, metadata)를 파싱하며 다음 단계 에이전트를 순차적으로 가동합니다.
3. **사용자 인터랙션**: 단계 전환 시 마다 중간 산출물 링크를 사용자에게 보고하여 피드백을 수집하고 승인을 얻습니다.
4. **RTK 최적화 및 최종 종료**: 최종 제안서 작성이 완료되면 `rtk gain` 결과를 참조하여 `_workspace/rtk_savings_report.md`를 자동 생성하고 사용자에게 보고를 끝마칩니다.
