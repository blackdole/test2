import urllib.request
import urllib.error
import json
import os
from datetime import datetime, timedelta

KEY = "903314d338884c8add429ceb5165d7ca"
TOKEN = "ATTA3b501f890cf4bec933e5b96b301ec072469cc99875d4d5aa9d5a99f776464aaeDF53C878"
BOARD_ID = "oWxJLZZu"
DONE_LIST_ID = "68c631a5fc0079417bed3d40"

MEMBER_MAP = {
    "5594cc21f93e3bfe0be229cf": "강민주",
    "5aea632a26ef169fd086661e": "이광용",
    "5c2f16a1042c298895da1715": "임진균"
}

def get_category(card_name):
    name_lower = card_name.lower()
    if "분석서비스" in name_lower:
        return "분석서비스"
    elif "분석관리자" in name_lower:
        return "분석관리자"
    elif "적격관리자" in name_lower:
        return "적격관리자"
    elif "로봇" in name_lower:
        return "로봇"
    elif "a2" in name_lower:
        return "a2"
    elif "신규 마이닝" in name_lower or "입력2" in name_lower:
        return "신규 마이닝 (입력2)"
    else:
        # Fallback category based on name contents
        return "분석관리자"

def is_holiday(dt):
    # 1. 주말
    if dt.weekday() >= 5:
        return True
    # 2. 매년 고정 공휴일 (양력)
    fixed_holidays = {
        (1, 1),    # 신정
        (3, 1),    # 삼일절
        (5, 1),    # 근로자의 날
        (5, 5),    # 어린이날
        (6, 6),    # 현충일
        (8, 15),   # 광복절
        (10, 3),   # 개천절
        (10, 9),   # 한글날
        (12, 25)   # 성탄절
    }
    if (dt.month, dt.day) in fixed_holidays:
        return True
    # 3. 2026년 대체공휴일 및 이동 공휴일
    moving_holidays_2026 = {
        (2, 16), (2, 17), (2, 18),  # 설날 연휴
        (3, 2),                     # 삼일절 대체공휴일
        (5, 25),                    # 부처님오신날 대체공휴일
        (6, 3),                     # 지방선거일
        (8, 17),                    # 광복절 대체공휴일
        (9, 24), (9, 25), (9, 26),  # 추석 연휴
        (10, 5)                     # 개천절 대체공휴일
    }
    if dt.year == 2026 and (dt.month, dt.day) in moving_holidays_2026:
        return True
    return False

def main():
    print("Fetching cards from Trello...")
    cards_url = f"https://api.trello.com/1/boards/{BOARD_ID}/cards?key={KEY}&token={TOKEN}&members=true"
    try:
        req = urllib.request.Request(cards_url, headers={'User-Agent': 'Mozilla/5.0'})
        with urllib.request.urlopen(req) as res:
            cards = json.loads(res.read().decode('utf-8'))
    except urllib.error.URLError as e:
        raise Exception(f"Failed to fetch cards: {e}")
    
    # We filter cards in the DONE list
    done_cards = [c for c in cards if c["idList"] == DONE_LIST_ID]
    
    # Initialize categories
    categories = {
        "분석서비스": [],
        "분석관리자": [],
        "로봇": [],
        "a2": [],
        "적격관리자": [],
        "신규 마이닝 (입력2)": []
    }
    
    # Distribute cards (preserving original names as per the rules)
    for card in done_cards:
        card_name = card["name"]
        cat = get_category(card_name)
        categories[cat].append(card_name)
        
    # Writers: we can default to the list of authors in the template
    # or look at who is active. The template lists "강민주, 이광용, 임진균".
    # We will output this fixed list as required.
    writers = ["강민주", "이광용", "임진균"]
    
    # Compute reporting period: Monday to Friday of the current week, adjusting for holidays
    today = datetime.now()
    monday = today - timedelta(days=today.weekday())
    friday = monday + timedelta(days=4)
    
    # Find the first non-holiday weekday
    start_date = monday
    while start_date <= friday and is_holiday(start_date):
        start_date += timedelta(days=1)
        
    # Find the last non-holiday weekday
    end_date = friday
    while end_date >= monday and is_holiday(end_date):
        end_date -= timedelta(days=1)
        
    # Fallback if the whole week is holiday
    if start_date > end_date:
        start_date = monday
        end_date = friday
        
    period_str = f"{start_date.strftime('%Y. %m. %d')} ~ {end_date.strftime('%m. %d')}"
    
    trello_data = {
        "period": period_str,
        "writers": writers,
        "this_week": categories,
        "next_week": {
            "분석관리자, a2, 로봇": [
                "유지보수작업"
            ]
        }
    }
    
    current_dir = os.path.dirname(os.path.abspath(__file__))
    output_path = os.path.join(current_dir, "trello_data.json")
    
    with open(output_path, "w", encoding="utf-8") as f:
        json.dump(trello_data, f, ensure_ascii=False, indent=2)
        
    print(f"Successfully collected {len(done_cards)} cards and saved to {output_path}")

if __name__ == "__main__":
    main()
