import subprocess
import sys
import os
import json

def main():
    current_dir = os.path.dirname(os.path.abspath(__file__))
    workspace_dir = current_dir
    
    # Decouple development environment paths and default to the running Python interpreter
    venv_python = os.environ.get("HWP_VENV_PYTHON", sys.executable or "python3")
    python_path = os.environ.get("HWP_LIBS_PATH", "")
    
    env = os.environ.copy()
    if python_path:
        env["PYTHONPATH"] = python_path + (os.pathsep + env.get("PYTHONPATH", "") if env.get("PYTHONPATH") else "")
    
    print("Step 1: Running collect_trello.py...")
    res = subprocess.run([venv_python, os.path.join(workspace_dir, "collect_trello.py")], env=env)
    if res.returncode != 0:
        print("Error: collect_trello.py failed.")
        sys.exit(res.returncode)
        
    print("Step 2: Running hwp_fill.py...")
    res = subprocess.run([venv_python, os.path.join(workspace_dir, "hwp_fill.py")], env=env)
    if res.returncode != 0:
        print("Error: hwp_fill.py failed.")
        sys.exit(res.returncode)
        
    # Get generated HWP path from trello_data.json
    data_path = os.path.join(workspace_dir, "trello_data.json")
    with open(data_path, "r", encoding="utf-8") as f:
        data = json.load(f)
    period = data["period"]
    parts = period.split("~")
    year = parts[0].strip().split(".")[0].strip()
    end_date_part = parts[1].strip()
    end_month, end_day = [x.strip() for x in end_date_part.split(".")]
    date_str = f"{year}-{end_month}-{end_day}"
    hwp_path = os.path.join(workspace_dir, f"연구개발3팀-업무보고({date_str}).hwp")
    
    print("Step 3: Running slack_sender.py...")
    res = subprocess.run([venv_python, os.path.join(workspace_dir, "slack_sender.py"), hwp_path], env=env)
    if res.returncode != 0:
        print("Error: slack_sender.py failed.")
        sys.exit(res.returncode)
        
    print("Pipeline run successfully complete!")

if __name__ == "__main__":
    main()
